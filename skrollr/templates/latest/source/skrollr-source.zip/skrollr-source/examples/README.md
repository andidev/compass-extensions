Examples
------

Showcasing the awesomeness of skrollr.

* [The "main" example](http://prinzhorn.github.com/skrollr/)
* [Demonstrating different anchors](http://prinzhorn.github.com/skrollr/examples/anchors.html)
* [Demonstrating data-anchor-target](http://prinzhorn.github.com/skrollr/examples/anchor_target.html)
* [Creating a fixed nav](http://prinzhorn.github.com/skrollr/examples/fixed_nav.html)
* [Using two custom easing functions to create a circular motion](http://prinzhorn.github.com/skrollr/examples/circular_motion.html)
* [Parallax background with constant speed](http://prinzhorn.github.com/skrollr/examples/bg_constant_speed_less.html)
* [gradientsmotherfucker](http://prinzhorn.github.com/skrollr/examples/gradientsmotherfucker.html)
