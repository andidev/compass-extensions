require 'compass'
Compass::Frameworks.register("animate", :path => "#{File.dirname(__FILE__)}/..")

module Animate

  VERSION = "0.1"
  DATE = "2012-05-24"

end