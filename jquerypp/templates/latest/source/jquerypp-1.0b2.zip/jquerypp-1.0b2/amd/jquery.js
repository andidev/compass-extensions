define([], function() { 
 return jQuery;
})