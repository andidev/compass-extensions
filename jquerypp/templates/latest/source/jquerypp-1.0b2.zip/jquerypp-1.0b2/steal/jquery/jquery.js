steal('can/util/jquery/jquery.1.7.1.js')
