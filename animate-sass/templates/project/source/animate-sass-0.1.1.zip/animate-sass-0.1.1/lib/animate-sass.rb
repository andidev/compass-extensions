require 'compass'
Compass::Frameworks.register("animate-sass", :path => "#{File.dirname(__FILE__)}/..")

module AnimateSass
  
  VERSION = "0.1.1"
  DATE = "2011-11-26"

end